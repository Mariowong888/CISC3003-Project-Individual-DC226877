<!--Splitting the header and footer into separate documents makes things easier!-->
<?php
  include_once 'header.php';
?>

<section class="index-intro">
  <h1>Hi I am Wong Chak Wun, std is DC226877.</h1>
</section>
